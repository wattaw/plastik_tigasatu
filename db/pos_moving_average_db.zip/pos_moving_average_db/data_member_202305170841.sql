INSERT INTO pos_forecasting_moving_average.`member` (kode_member,nama,alamat,telepon,created_at,updated_at) VALUES
	 ('00001','Ningsih','Sambisari','081217383222','2023-03-23 04:01:13','2023-04-09 22:05:15'),
	 ('00002','Muhammad Anton','Jemundo','081234779987','2023-03-25 08:54:03','2023-04-09 22:05:23'),
	 ('00003','Dwi Aditya','Kedungturi','089626327754','2023-03-25 08:54:14','2023-04-09 22:05:36'),
	 ('00004','Suprapto','Jemundo','088223112665','2023-04-14 14:35:19','2023-04-14 14:35:19'),
	 ('00005','budi','surabaya','082637123','2023-04-14 20:06:34','2023-04-14 20:06:34');
