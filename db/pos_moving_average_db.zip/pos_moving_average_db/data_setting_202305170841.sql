INSERT INTO pos_forecasting_moving_average.setting (nama_perusahaan,alamat,telepon,tipe_nota,diskon,path_logo,path_kartu_member,created_at,updated_at) VALUES
	 ('Plastik Tiga Satu','Jln Jemundo Gang Sawunggaling 2, Taman Sidoarjo','081939222555',2,5,'/img/logo-20230325161427.png','/img/logo-2023-04-14055307.jpg',NULL,'2023-04-13 22:53:07');
