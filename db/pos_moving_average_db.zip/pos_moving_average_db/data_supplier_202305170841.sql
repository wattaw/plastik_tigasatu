INSERT INTO pos_forecasting_moving_average.supplier (nama,alamat,telepon,created_at,updated_at) VALUES
	 ('Yudi','sidoarjo','085388227653','2023-03-23 04:02:42','2023-04-08 22:20:17'),
	 ('Hendra','sidoarjo','081664788312','2023-03-25 09:01:08','2023-04-08 22:20:05');
