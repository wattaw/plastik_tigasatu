INSERT INTO pos_forecasting_moving_average.pengeluaran (deskripsi,nominal,created_at,updated_at) VALUES
	 ('beli rak besi',1000000,'2023-03-23 04:03:06','2023-04-08 22:26:03'),
	 ('beli alat kebersihan',200000,'2023-03-25 09:01:46','2023-03-25 09:01:46'),
	 ('beli nota',150000,'2023-04-08 22:26:40','2023-04-08 22:26:40'),
	 ('restock bulan april',2000000,'2023-04-12 13:57:54','2023-04-13 23:56:02');
